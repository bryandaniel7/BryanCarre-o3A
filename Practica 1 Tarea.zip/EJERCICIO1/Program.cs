﻿internal class Program
{
    private static void Main(string[] args)
    {
        mayor M= new mayor(45,56);
        M.imprimir();
    }
}