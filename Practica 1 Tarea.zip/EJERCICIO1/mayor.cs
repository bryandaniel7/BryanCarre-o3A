class mayor:numeros{

    public mayor(double numero1, double numero2):base(numero1, numero2){
    }
 
 public double Nmayor(){
    if(numero1>numero2){
        return numero1;
    }
    else
    {
        return numero2;
    }
    
 }
 
public new void imprimir(){

    Console.WriteLine("El primer número es: "+ numero1 +", su segund número es: "+ numero2);
    Console.WriteLine("Y el número mayor es: "+ Nmayor());
}
 

}