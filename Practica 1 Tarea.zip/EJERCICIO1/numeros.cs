class numeros{

public double numero1{get;set;}
public double numero2{get;set;}

public numeros(double numero1, double numero2){
this.numero1=numero1;
this.numero2=numero2;
}

public void imprimir(){

    Console.WriteLine("El primer número es: "+ numero1 +", su segundo número es: "+ numero2);
}

}