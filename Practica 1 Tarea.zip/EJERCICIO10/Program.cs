﻿internal class Program
{
    private static void Main(string[] args)
    {
        int d;
        int f=1;
        int c=0;
        do{
            Console.WriteLine("Ingrese un numero entero");
            d=Convert.ToInt32(Console.ReadLine());
            if (d<0){
                Console.WriteLine("Numero ingresado no valido, recuerde que el numero ingresado no debe ser menor a 0");
            }
        } while (d<0);
        do {
            c=c +1;
            f*=c;

        } while (d>c);
        Console.WriteLine("El factorial de " +d+ " es "+f);
    }
}