﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Escriba un número:");
        par P= new par(Console.Read());
        P.Npar();
    }
}