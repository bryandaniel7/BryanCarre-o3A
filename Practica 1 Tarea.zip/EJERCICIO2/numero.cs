class numero{

    public int numero1{get;set;}
    public numero(int numero1){
        this.numero1=numero1;
    }

}