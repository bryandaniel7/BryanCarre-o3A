class par:numero{

    public par(int numero1):base(numero1){

    }

    public void Npar(){
        if((numero1 % 2)==0){
             Console.WriteLine("El número es par");
             
        }
        else{
            Console.WriteLine("El número no es par");
            
        }
    }

}