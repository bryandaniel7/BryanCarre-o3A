﻿internal class Program
{
    private static void Main(string[] args)
    {
        mayor M= new mayor(23, 52, 85);
        M.imprimir();
        
    }
}