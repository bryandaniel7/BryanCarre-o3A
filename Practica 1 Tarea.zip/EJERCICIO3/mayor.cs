class mayor:numeros{

    public mayor(double numero1, double numero2, double numero3):base(numero1, numero2, numero3){
    }
 
 public double Nmayor(){
    double Mayor= numero1;
    if(numero2> Mayor){
        Mayor=numero2;
    }
    if(numero3>Mayor)
    {
        Mayor= numero3;
    }
    return Mayor;
    
 }
 
public new void imprimir(){
    Console.WriteLine("Su primer número es: "+ numero1 +", su segundo número es: "+ numero2 +", su tercer número es: "+ numero3);
    Console.WriteLine("Y el número mayor es: "+ Nmayor());
}
 

}