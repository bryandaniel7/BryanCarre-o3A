class numeros{

public double numero1{get;set;}
public double numero2{get;set;}
public double numero3{get;set;}

public numeros(double numero1, double numero2, double numero3){
this.numero1=numero1;
this.numero2=numero2;
this.numero3=numero3;
}

public void imprimir(){

    Console.WriteLine("Su primer número es: "+ numero1 +", su segundo número es: "+ numero2 +", su tercer número es: "+ numero3);
}

}