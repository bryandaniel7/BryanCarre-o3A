﻿internal class Program
{
    //Escribir un programa que lea exactamente 8 números y luego escriba la suma de todos ellos
    private static void Main(string[] args)
    {
        double N;
        double s=0;
        for (int C=0;C<8;C++){
            
            Console.WriteLine("Ingrese un número: ");
            N = Convert.ToInt32(Console.ReadLine());
            s+=N;
            if (C==7){
                Console.WriteLine("La suma de los ocho números es: "+s);
            }
            
        }
    }
}