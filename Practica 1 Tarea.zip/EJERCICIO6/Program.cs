﻿internal class Program
{
    private static void Main(string[] args)
    {
        double s=0;
        double N;
        double A=1;
        while (A!=0){
            Console.WriteLine("Ingrese la cantidad de digitos que va a sumar:");
            A=Convert.ToInt32(Console.ReadLine());
            do{
            Console.WriteLine("Ingrese un número que no sea 0");
            N=Convert.ToInt32(Console.ReadLine());
            s+=N;
            A=A-1;
            }while(A>0);
            if (A==0){
                Console.WriteLine("La suma total de todos los números es: "+s);
                Console.WriteLine("El programa finalizó");
            }
        }
    }
}