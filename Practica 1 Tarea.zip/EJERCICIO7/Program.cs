﻿internal class Program
{
    private static void Main(string[] args)
    {
        string A="S";
        while (A == "S"){
            if (A =="S"){
                double N1;
                double N2;
                double N3;
                Console.WriteLine("Ingrese el primer número");
                N1=Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Ingrese el segundo número");
                N2=Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Ingrese el tercer número");
                N3=Convert.ToDouble(Console.ReadLine());
                if (N1==N2 && N1==N3){
                    Console.WriteLine("Los números ingresados forman un triangulo equilatero");
                }
                else {
                    if (N1==N2 || N2==N3 || N1==N3){
                        Console.WriteLine("Los números ingresados forman un triangulo isosceles");
                    }
                    else {
                        Console.WriteLine("Los números ingresados forman un triangulo escaleno");
                    }
                }
                
                Console.WriteLine("Si desea continuar ingrese S caso contrario N para finalizar");
                A = Console.ReadLine();
                
                if (A=="N"){
                    Console.WriteLine("Programa finalizado");
                }
                else{
                    Console.WriteLine("Si desea continuar ingrese S caso contrario N para finalizar");
                    A = Console.ReadLine();
                }
            }
        }
    }
}