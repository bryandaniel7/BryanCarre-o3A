﻿internal class Program
{
    private static void Main(string[] args)
    {
        for (int c=1;c<=3000;++c){
            if(c%3==0){
                Console.WriteLine(c+" es mutiplo de 3");
            }
            
        }
    }
}