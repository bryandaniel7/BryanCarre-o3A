﻿internal class Program
{
    private static void Main(string[] args)
    {
        double s=0;
        double d=-1;
        double N=1;
        double r=0;
        while (N!=0){
            Console.WriteLine("Ingrese un numero, si ingresa el 0 el programa terminará y mostrara la media aritmetica de los numeros ingresados");
            N=Convert.ToDouble(Console.ReadLine());
            s+=N;
            d=d+1;
            if (N==0){
                r=s/d;
                Console.WriteLine("La media aritmetica de los numero que ingresó es "+r);
                Console.WriteLine("Programa finalizado");
            }
        }
    }
}